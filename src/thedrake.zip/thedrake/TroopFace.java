package thedrake;

public enum TroopFace {
    AVERS,
    REVERS
}
